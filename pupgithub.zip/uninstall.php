<?php
if (!defined('WP_UNINSTALL_PLUGIN')) exit;

// Par défaut, ne supprime rien (sécurité).
// Si tu veux : delete_option + drop tables (avec un flag “hard uninstall”).
